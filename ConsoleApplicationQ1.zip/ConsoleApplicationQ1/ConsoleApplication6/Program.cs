﻿using System;

// Step 1: Define a user-defined exception by inheriting from Exception class
public class InvalidAgeException : Exception
{
    public InvalidAgeException(string message) : base(message)
    {
    }
}

class Program
{
    static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Enter your age:");
            int age = int.Parse(Console.ReadLine());

            // Step 2: Raise the user-defined exception if the condition is met
            if (age < 18)
            {
                throw new InvalidAgeException("Age must be 18 or older.");
            }

            Console.WriteLine("You are eligible to vote.");
        }
        catch (InvalidAgeException ex)
        {
            // Step 3: Catch and handle the user-defined exception
            Console.WriteLine($"User-defined exception: {ex.Message}");
        }
        catch (Exception ex)
        {
            // Catch other system-defined exceptions
            Console.WriteLine($"System exception: {ex.Message}");
        }
        finally
        {
            // Optional: Finally block to execute code whether an exception occurs or not
            Console.WriteLine("Process completed.");
        }
        Console.ReadKey();
    }
}
